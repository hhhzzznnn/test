import Header from './Header';
import {
  Switch,
  Route,
  HashRouter,
} from "react-router-dom"; 
import { useMemo } from 'react';
import routes from '@/router';

const Layout = () => {
  const pageList = useMemo(() => {
    const result = [];
    const traversal = (routes, baseUrl) => {
      for(let i = 0; i < routes?.length; i++) {
        const fullPath = `${baseUrl}` + routes[i].path;
        if (routes[i].component) {
          result.push({
            ...routes[i],
            path: fullPath,
          });
        }
        if (routes[i].children) {
          traversal(routes[i].children, fullPath)
        }
      }
    }
    traversal(routes, '');
    return result;
  }, [routes]);

    return (
      <HashRouter> 
        <Switch>
          <>   
            <Header />
            <div style={{height: 'calc(100% - 103px)'}}>
            {
              pageList.map((item) => (
                <Route
                  exact
                  key={item.path}
                  path={item.path}
                  component={item.component}
                />
              ))
            }
            </div>
          </>
        </Switch>  
      </HashRouter>
    );
};

export default Layout;