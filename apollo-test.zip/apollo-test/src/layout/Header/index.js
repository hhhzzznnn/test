import NavTab from './NavTab';
import NavContent from './NavContent';
import Info from './Info';
import './index.less';
import Logo from '@/assets/imgs/logo.svg';
import { useCallback, useState } from 'react';

const Header = () => {
  return (
    <div>
      <div className='header'>
        <div className='align-center'>
          <img src={Logo} alt="" className='header-logo'/>
          <NavTab />
        </div>
        <Info />
      </div>
      <NavContent />
    </div>
  )
};

export default Header;