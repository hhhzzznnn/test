import { useState, memo, useEffect } from 'react';
import routes from '@/router';
import navIcon from '@/assets/imgs/nav-icon1.svg';
import navActiveIcon from '@/assets/imgs/home-active.svg';
import { useHistory, useLocation } from 'react-router';
import { useDispatch } from 'react-redux'
import { setList, setBaseUrl } from '@/store/nav';

const NavTab = memo(() => {
    const [active, setActive] = useState('');
    const history = useHistory();
    const location = useLocation();
    const dispatch = useDispatch();
    const selectPath = location.pathname.match(/(\/[a-zA-Z]+)\//);

    const children = !!selectPath ? 
      routes?.find((item) => item.path === selectPath[1])?.children
      : routes[0].children;

    useEffect(() => {
      dispatch(setList(children));
    }, [dispatch, children]);

    return (
        <div className="nav-tab">
            {
                routes.map((item) => 
                  <div 
                    className={active === item.name ?'active nav-tab-item': 'nav-tab-item'}
                    key={item.name}
                    onClick={() => { 
                      const path = item.redirect ? item.redirect : item.path;
                      history.push(path);
                      setActive(item.name);
                      dispatch(setList(item.children));
                      dispatch(setBaseUrl(item.path));
                    }}
                  >
                    <img src={active === item.name ? navActiveIcon:navIcon} className='nav-icon'/>
                    {item.name}
                  </div>
                )
            }
        </div>
    );
});

export default NavTab;