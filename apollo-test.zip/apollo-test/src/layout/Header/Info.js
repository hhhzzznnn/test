import Button from '@/components/Button';
import searchIcon from '@/assets/imgs/search.svg';
import settingIcon from '@/assets/imgs/setting.svg';
import messageIcon from '@/assets/imgs/message.svg';
import userInfoIcon from '@/assets/imgs/user-info.svg';

const Info = () => {
    return (
        <div className='header-info'>
            <Button>Upgrade</Button>
            <img src={searchIcon} className='seach' />
            <img src={messageIcon} className='seach' />
            <img src={settingIcon} className='seach' />
            <img src={userInfoIcon} className='seach' />
        </div>
    );
};

export default Info;