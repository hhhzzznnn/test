import { useHistory, useLocation } from "react-router";
import { useSelector } from 'react-redux';

const NavContent = () => {
    const history = useHistory();
    const location = useLocation();
    const fullPath = location.pathname;
    const list = useSelector(state => state.nav.value);
    const baseUrl = useSelector(state => state.nav.baseUrl);
    
    return (
      <div className="nav-content">
        {
          list?.map((item) => {
              return (
                  <div 
                    onClick={() => history.push(`${baseUrl + item.path}`)}
                    className={fullPath.includes(item.path) ? 'active nav-content-item': "nav-content-item"} 
                    key={item.name}
                  >
                    {item.name}
                  </div>
              )
          })
        }
      </div>
    );
};

export default NavContent;