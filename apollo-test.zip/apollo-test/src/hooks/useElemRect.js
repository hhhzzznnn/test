import { useState, useLayoutEffect, useRef } from 'react';
import _ from 'lodash';

const rectKeys = ['width', 'height', 'x', 'y'];

const useElemRect = (elem) => {
  const mountedSaved = useRef();
  const [rect, setRect] = useState(elem
    ? _.pick(elem.getBoundingClientRect(), rectKeys)
    : {
    x: 0,
    y: 0,
    height: 0,
    width: 0,
  });

  useLayoutEffect(() => {
    mountedSaved.current = true;
    return () => {
      mountedSaved.current = false;
    };
  }, []);

  useLayoutEffect(() => {
    if (!elem) {
      return () => {};
    }
    let animationFrameID = null;
    const observer = new ResizeObserver(() => {
      const _rect = _.pick(elem.getBoundingClientRect(), rectKeys);
      animationFrameID = window.requestAnimationFrame(() => {
        if (mountedSaved.current) {
          if (Object.keys(rect).some((key) => _rect[key] !== rect[key])) {
            setRect(_rect);
          }
        }
      });
    });
    observer.observe(elem);
    return () => {
      observer.disconnect();
      window.cancelAnimationFrame(animationFrameID);
    };
  });

  return rect;
};

export default useElemRect;
