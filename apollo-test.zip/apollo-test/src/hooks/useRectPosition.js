import { useMemo } from 'react';

const useRectPosition = (containerWidth, containerHeight, rect) => {

  const position = useMemo(() => {
    const { clientWidth } = document.documentElement;
    const { clientHeight } = document.documentElement;
    let _x = rect.x;
    let _y = rect.y + rect.height;
    if (_x > clientWidth - containerWidth) {
      _x = clientWidth - containerWidth;
    }
    if (_y > clientHeight - containerHeight) {
      _y = rect.y - containerHeight;
    }
    return [_x, _y];
  }, [
    rect,
    containerWidth,
    containerHeight,
  ]);

  return position;
};

export default useRectPosition;
