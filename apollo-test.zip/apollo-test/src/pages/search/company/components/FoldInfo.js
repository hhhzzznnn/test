import { Input,Tooltip } from 'antd';
import { useState } from 'react';
import Button from '@/components/Button';
import arrowIcon from '@/assets/imgs/arrow-blue.svg';

const { TextArea } = Input;

const FoldInfo = () => {
  const [collapse, setCollapse] = useState(false);
  return (
    <div className='fold-info'>
      <div className="fold-title" onClick={() => setCollapse(!collapse)}> 
       Include / exclude list of companies
      <img src={arrowIcon} alt="" style={{width: 8, height: 8 }}/>
      
      
      </div>
      {
        collapse && (
          <>
            <div className='fold-tip'>
               Include list of companies 
            </div>
            <TextArea 
              className='fold-textarea'
              autoSize={{
                minRows: 4,
              }}
              placeholder={`  e.g 
  http://cisco.com
  john@apple.com
  www.dell.com
  salesforce.com`}/>
            <Button block={true}>Save and Search</Button>
            {/* <Tooltip placement='center' title='Do you only have the company names? You can enrich them with websites for free by uploading them in a CSV file here. Once you finish the import, you can find them in the companies tab and export the results (filter by the file name under CSV Import). Please allow up to 1-2 hours for the enrichment to complete.'> */}
              <div className='info-bottom'>I only have company names</div>
            {/* </Tooltip> */}
            <div className='fold-tip'> Exclude list of companies </div>
            <TextArea 
              className='fold-textarea'
              autoSize={{
                minRows: 4,
              }}
              placeholder={`  e.g 
  http://cisco.com
  john@apple.com
  www.dell.com
  salesforce.com`}/>
            <Button block={true}>Save and Search</Button>
            {/* <Tooltip placement='center' title='Do you only have the company names? You can enrich them with websites for free by uploading them in a CSV file here. Once you finish the import, you can find them in the companies tab and export the results (filter by the file name under CSV Import). Please allow up to 1-2 hours for the enrichment to complete.'> */}
              <div className='info-bottom'>I only have company names</div>
            {/* </Tooltip> */}
          </>
        )
      }
    </div>
  );
};

export default FoldInfo;