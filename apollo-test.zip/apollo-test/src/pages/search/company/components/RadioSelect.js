import { useState } from 'react';
import RadioItem from './RadioItem';
import { Radio } from 'antd';
import FoldInfo from './FoldInfo';

const list = [
  {
    text: 'Is any of',
    id: 1,
  },
  {
    text: 'Is Known',
    id: 2,
  },
  {
    text: 'Is unKnown',
    id: 3,
  }
]

const RadioSelect = () => {
  const [activeId, setActiveId] = useState(true);
  return (
    <>
      <Radio.Group style={{width: '100%'}}>
      {
        list.map((item) => <RadioItem 
          key={item.id} 
          activeId={activeId} 
          info={item}
          onChange={(data) => setActiveId(data)}
        />)
      } 
      </Radio.Group>
      <FoldInfo />
    </>
  );
};

export default RadioSelect;