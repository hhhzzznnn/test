import { useState } from 'react';
import RadioItem from './RadioItem';

const list = [
  {
    text: 'Is any of',
    id: 1,
  },
  {
    text: 'Is Known',
    id: 2,
  },
  {
    text: 'Is unKnown',
    id: 3,
  }
]

const RadioSelect = () => {
  const [activeId, setActiveId] = useState(true);
  return (
    <>
      {
        list.map((item) => <RadioItem 
          key={item.id} 
          activeId={activeId} 
          info={item}
          onChange={(data) => setActiveId(data)}
         />)
      }  
    </>
  );
};

export default RadioSelect;