import Select from '@/components/Select';
import { useState } from 'react';

const RadioItem = ({ info, onChange, activeId }) => {
  const [listVal, setListVal] = useState('');
  return (
    <div
        className={`${info.id === activeId  ? 'select-active': ''} radio-select`}
        onClick={() => onChange(info.id)}
    >
        <div className='radio-text'>
          <input 
            type="radio" 
            style={{marginRight: 10}}
            checked={info.id === activeId}
            onChange={() => {}}
          />
          {info.text}
        </div>
        {
          info.id === 1 && info.id === activeId && (
          <div style={{marginTop: 10}}>
            <Select 
              list={[
                {
                    id: 1,
                    name: '111'
                }, {
                    id: 2,
                    name: '222',
                }
              ]} 
              value={listVal}
              onChange={(v) => setListVal(v)}
              placeholder='Enter companies...'
            />
          </div>
      )
    } 
    </div>
  );
};

export default RadioItem;