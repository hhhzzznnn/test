import { useState } from 'react';
import { Select, Checkbox, Radio } from 'antd';

const RadioItem = ({ info, onChange, activeId }) => {
  const [listVal, setListVal] = useState();
  const [list2, setList2] = useState([]);
  const [list3, setList3] = useState([]);
  const [radioCheck, setRadioCheck] = useState(info.id);
  const [check1, setCheck1] = useState(false);
  const [check2, setCheck2] = useState(false);

  return (
    <div
        className={`${info.id === activeId  ? 'select-active': ''} radio-select`}
        onClick={() => onChange(info.id)}
    >
      <div className='radio-text'>
        <Radio
          value={radioCheck}
          checked={radioCheck === info.id}
          onChange={() => setRadioCheck(radioCheck)}
          >
            {info.text}
        </Radio>
      </div>
      {
        info.id === 1 && (
        <div style={{marginBottom: 10}}>
          <Select
            prefixCls='test-select'
            value={listVal}
            mode="multiple"
            showSearch={true}
            onChange={(v) => setListVal(v)}
            placeholder='Enter companies...'
            options={[
              {
                value: 1,
                label: '111'
              }, {
                value: 2,
                lable: '222',
              }
            ]}
          />
        </div>
        )
      } 
      {
        info.id === 1 && (
          <>
            <div className='radio-text'>
              <Checkbox 
                onChange={() => setCheck1(!check1)} 
                checked={check1}>
                  Is not any of
              </Checkbox>
            </div>
            {
              check1 && (
                <div style={{marginBottom: 10}}>
                  <Select
                    prefixCls='test-select'
                    value={list2}
                    mode="multiple"
                    showSearch={true}
                    onChange={(v) => setList2(v)}
                    placeholder='Enter companies...'
                    options={[
                      {
                        value: 1,
                        label: '111'
                      }, {
                        value: 2,
                        lable: '222',
                      }
                    ]}
                  />
                </div>
              )
            }
            <div className='radio-text'>
              <Checkbox 
                checked={check2}
                onChange={() => setCheck2(!check2)}
              >
                Include past company
              </Checkbox>
            </div>
            {
              check2 && (
                <div style={{marginBottom: 10}}>
                <Select
                  prefixCls='test-select'
                  value={list3}
                  mode="multiple"
                  showSearch={true}
                  onChange={(v) => setList3(v)}
                  placeholder='Enter companies...'
                  options={[
                    {
                      value: 1,
                      label: '111'
                    }, {
                      value: 2,
                      lable: '222',
                    }
                  ]}
                />
              </div>
              )
            }
          </>
        )
      }
    </div>
  );
};

export default RadioItem;