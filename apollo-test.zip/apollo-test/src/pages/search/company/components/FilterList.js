import Input from '@/components/Input';
import Button from '@/components/Button';
import FilterItem from './FilterItem';
import CompanyFilter from './CompanyFilter';
import RadioSelect from './RadioSelect';
import { useState } from 'react';

const filterList = [
    {
        name: 'Lists',
        component: RadioSelect,
    },
    {
        name: 'Persona',
        component: RadioSelect,
    },
    {
        name: 'Name',
        component: RadioSelect,
    },
    {
        name: 'Job Titles',
        component: RadioSelect,
    },
    {
        name: 'Company',
        component: RadioSelect,
    },
    {
        name: 'Location',
        component: RadioSelect,
    },
    {
        name: 'Employees',
        component: RadioSelect,
    },
    {
        name: 'Lists1',
        component: RadioSelect,
    },
    {
        name: 'Persona1',
        component: RadioSelect,
    },
    {
        name: 'Name1',
        component: RadioSelect,
    },
    {
        name: 'Job Titles11',
        component: RadioSelect,
    },
    {
        name: 'Company1',
        component: RadioSelect,
    },
    {
        name: 'Location1',
        component: RadioSelect,
    },
    {
        name: 'Employees1',
        component: CompanyFilter,
    },

]

const FilterList = () => {
    const [active, setActive] = useState();

    return (
        <div className='filter-list'>
            <Input onChange={() => {}} placeholder='Search People...'/>
            <div className='filter-condition'>
                <span className='filter-text'>Filter</span>
                <span className='condition-tip'>Load | Save & Subscribe</span>
            </div>
            <div className='list-content'>
            {
                filterList.map((item) => {
                    return (
                        <FilterItem
                            info={item} 
                            key={item.name}
                            active={item.name === active}
                            cb={(data) => setActive(data)}
                        />)
                })
            }
            </div>
        
            <div className='more-filters'>
                <Button block={true}>
                    More Filters
                </Button>
            </div>
        </div>
    );
};

export default FilterList;