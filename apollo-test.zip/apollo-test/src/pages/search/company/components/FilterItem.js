import iconUser from '@/assets/imgs/user.svg';
import dropDown from '@/assets/imgs/dropDown.svg';
import { useState } from 'react';
import { jsx as _jsx } from 'react/jsx-runtime';

const FilterItem = ({ info, active, cb }) => {
    const [collapse, setCollapse] = useState(true);
    return (
        <div className={`filter-item-wrapper ${active && !collapse ? 'filter-active': ''}`}>
            <div 
                className={`filter-item`}
                onClick={() => {
                    setCollapse(!collapse);
                    cb(info.name);
                }}
            >
                <div>
                    <img src={iconUser} className="filter-item-icon"/>
                    {info.name}
                </div>
                <img src={dropDown} className="filter-item-icon"/>
            </div>
            {
                !collapse && (
                    <div className='filter-item-padding'>
                        {_jsx(info.component, {})}
                    </div>
                )
            }
        </div>
    );
};

export default FilterItem;