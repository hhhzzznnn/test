import { Table, Tooltip } from 'antd';
import twitterIcon from '@/assets/imgs/twitter.svg';
import facebookIcon from '@/assets/imgs/facebook.svg';
import linkIcon from '@/assets/imgs/link.svg';
import inIcon from '@/assets/imgs/in.svg';
import list1 from '@/assets/imgs/list1.svg';
import list2 from '@/assets/imgs/list2.svg';
import list3 from '@/assets/imgs/list3.svg';
import Button from '@/components/Button';
import { jsx as _jsx } from 'react/jsx-runtime';
import { useState } from 'react';

const FilterTable = () => {
  const clientHeight = window.innerHeight - 144 - 90;
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);

  const onSelectChange = (newSelectedRowKeys) => {
    setSelectedRowKeys(newSelectedRowKeys);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
  };

  return (
    <div className='filter-content-table'>
      <Table 
        prefixCls='test'
        onHeaderRow={() =>
          (<div style={{ backgroundColor: 'red'}}>111</div>)
        }
        rowSelection={rowSelection}
        className='filter-table'
        columns={columns} 
        dataSource={data} 
        rowClassName='row-sty'
        scroll={{
          // x: 'max-content', 
          // x: '100%',
          y: clientHeight,
        }}
        pagination={false}
      />
  </div>
  )
}
const tabList = [
  {
    name: 'Total',
    id: 1,
    component: FilterTable,
  },
  {
    name: 'Net New',
    id: 2,
    component: () => (<div>111</div>), 
  },
  {
    name: 'Saved',
    id: 3,
    component: () => (<div>222</div>),
  }
];
const columns = [
  {
    // title: 'Name',
    title: (<div className='tb-sty-title'>Name</div>),
    dataIndex: 'name',
    width: 150,
    fixed: true,
    render: (text) => (
    <div>
      <div className='tb-name'>{text}</div>
      <img src={inIcon} style={{marginTop: 8, width: 12, height:12}}/>
    </div>),
    sorter: (a, b) => {}
  },
  {
    title: 'Title',
    dataIndex: 'title',
    align: 'center',
    width: 200,
    sorter: (a, b) => {},
    render: (text) => (<div className='table-item'>{text}</div>)

  },
  {
    title: 'Company',
    dataIndex: 'company',
    width: 220,
    align: 'left',
    sorter: (a, b) => {},
    render: (text, info) => (
      <div className='table-item'>
        <img src={info.img} className='cmp-logo'/>
        <div className='cmp-info'>
          <a href=''>Web4Smart</a>
          <div>
            <img src={linkIcon} className='twitter-icon'/>
            <img src={inIcon} className='twitter-icon'/>
            <img src={facebookIcon} className='twitter-icon'/>
            <img src={twitterIcon} className='twitter-icon'/>
          </div>
        </div>
      </div>
    ),
  },
  {
    title: 'Quick Actions',
    dataIndex: 'actions',
    width: 200,
    align: 'center',
    render: (text) => <Button border={true}>
      <img src={require('/src/assets/imgs/envelope.svg')} style={{ width: 20, height: 20, marginRight: 4}}/>
      <span style={{color: '#5d6a7e'}}>Save Contact</span>
      </Button>
  },
  {
    title: 'Contact Location',
    dataIndex: 'location',
    width: 200,
    align: 'center',
  },
  {
    title: 'Industry',
    dataIndex: 'industry',
    width: 150,
    align: 'center',
    ellipsis: true,
    render: (text) => (<div>{text}</div>)
  },
  {
    title: 'Email',
    dataIndex: 'email',
    width: 150,
    align: 'center',
    ellipsis: true,
    render: (text) => <Button border={true}>
      <img src={require('/src/assets/imgs/envelope.svg')} style={{ width: 20, height: 20, marginRight: 4}}/>
      <img src={require('/src/assets/imgs/download.svg')} style={{ width: 18, height: 16 }}/>
      </Button>
  },
  {
    title: 'Employees',
    dataIndex: 'employees',
    width: 200,
    align: 'center',
  },
  {
    title: 'Keywords',
    dataIndex: 'keywords',
    width: 220,
    align: 'center',
    ellipsis: true,
    render: (text) => (
      <Tooltip title={'global health, global development, us education, philanthropy'}>
         <div className='text-over'>global health, global development, us education, philanthropy</div>
      </Tooltip> 
      )
  },
];

const data = [
  { name: 'Bill Gates', title: 'Co-chair', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 1, img: require('/src/assets/imgs/cmp1.jpeg'), industry: 'Staffing & Recruiting' },
  { name: 'Robert Gates', title: 'Principal Could Solution', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 2, img: require('/src/assets/imgs/cmp2.jpeg'), industry: 'Management Consulting'},
  { name: 'Yunming Shao', title: 'Managing Director', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 23, key: 3, img: require('/src/assets/imgs/cmp5.jpeg'), industry:'Information Technology & Services' },
  { name: 'Richard Branson', title: 'Founder', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 14 , img: require('/src/assets/imgs/cmp4.jpeg'), industry: 'Information Technology & Services'},
  { name: 'Jeff Weiner', title: 'Executive Chairman', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 56, key: 5, img: require('/src/assets/imgs/cmp1.jpeg'), industry: 'Staffing & Recruiting'},
  { name: 'Satya Nadella', title: 'Chairman and CEO', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 120, key: 6, img: require('/src/assets/imgs/cmp2.jpeg'), industry: 'Management Consulting'},
  { name: 'Arianna Huffington', title: 'Founder and CEO', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 1600, key: 7, img: require('/src/assets/imgs/cmp5.jpeg'),industry: 'Information Technology & Services'},
  { name: 'Robert Johnson', title: 'President/CEO', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 246, key: 8 , img: require('/src/assets/imgs/cmp4.jpeg'), industry: 'Staffing & Recruiting'},
  { name: 'Tony Robbins', title: 'Chairman', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 326, key: 9 , img: require('/src/assets/imgs/cmp1.jpeg'), industry: 'Management Consulting'},
  { name: 'Melinda Gates', title: 'Co-chair', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 126, key: 10, img: require('/src/assets/imgs/cmp2.jpeg') ,industry: 'Staffing & Recruiting'},
  { name: 'Jeff Gilfand', title: 'Chief Financial Officer (CFO)', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 11, img: require('/src/assets/imgs/cmp5.jpeg'),industry: 'Information Technology & Services'},
  { name: 'Sallie Krawcheck', title: 'CEO and Co-Founder', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 236, key: 12, img: require('/src/assets/imgs/cmp4.jpeg'),industry: 'Management Consulting'},
  { name: 'Deepak Chopra', title: 'Founder', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 874, key: 13, img: require('/src/assets/imgs/cmp1.jpeg'),industry: 'Staffing & Recruiting'},
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 12, key: 14, img: require('/src/assets/imgs/cmp2.jpeg') ,industry:'Information Technology & Services'},
  
];

const FilterContent = () => {
  const [active, setActive] = useState(1);
  const cmp = tabList.find((item) => item.id === active);
  return (
      <div className="filter-content">
        <div className="filter-content-head">
          <div className='filter-content-head'>
          <img src={list1} alt="" className='handle-icon'/>
          {
              tabList.map((item) => (
                <div 
                  className={`${active === item.id ? 'filter-content-head-active': ''} filter-content-head-item`}
                  key={item.id}
                  onClick={() => setActive(item.id)}
                >
                {item.name}
                </div>
              ))
            }
          </div>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            textAlign: 'right',
          }}>
            <img src={list1} alt="" className='handle-icon'/>
            <img src={list2} alt="" className='handle-icon'/>
            <img src={list3} alt="" className='handle-icon'/>
          </div>
        </div>
        {
          _jsx(cmp.component, {})
        }
      </div>
  );
};

export default FilterContent;