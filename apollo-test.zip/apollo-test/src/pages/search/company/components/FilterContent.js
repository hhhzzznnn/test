import Table from 'rc-table';
import companyPic from '@/assets/imgs/picture.jpeg';
import twitterIcon from '@/assets/imgs/twitter.svg';
import list1 from '@/assets/imgs/list1.svg';
import list2 from '@/assets/imgs/list2.svg';
import list3 from '@/assets/imgs/list3.svg';
import Button from '@/components/Button';
import { jsx as _jsx } from 'react/jsx-runtime';
import { useState } from 'react';

const FilterTable = () => {
  const clientHeight = window.innerHeight - 144 - 90;
  return (
    <div className='filter-content-table'>
      <Table 
        className='filter-table'
        columns={columns} 
        data={data} 
        rowClassName='row-sty'
        scroll={{
          x: 'max-content', 
          y: clientHeight,
        }}
      />
  </div>
  )
}
const tabList = [
  {
    name: 'Total',
    id: 1,
    component: FilterTable,
  },
  {
    name: 'Net New',
    id: 2,
    component: () => (<div>111</div>), 
  },
  {
    name: 'Saved',
    id: 3,
    component: () => (<div>222</div>),
  }
];
const columns = [
  {
    title: 'Name',
    dataIndex: 'name',
    width: 200,
    align: 'center',
    render: (text) => (
    <div>
      <div>{text}</div>
      <img src={twitterIcon} style={{marginTop: 10, width: 16, height:16}}/>
    </div>)
  },
  {
    title: 'Title',
    dataIndex: 'title',
    align: 'center',
    width: 200,
    render: (text) => (<div className='table-item'>{text}</div>)

  },
  {
    title: 'Company',
    dataIndex: 'company',
    width: 200,
    render: () => (
      <div className='table-item'>
        <img src={companyPic} className='cmp-logo'/>
        <div className='cmp-info'>
          <a href=''>Web4Smart</a>
          <div>
            <img src={twitterIcon} className='twitter-icon'/>
            <img src={twitterIcon} className='twitter-icon'/>
            <img src={twitterIcon} className='twitter-icon'/>
            <img src={twitterIcon} className='twitter-icon'/>
          </div>
        </div>
      </div>
    ),
  },
  {
    title: 'Quick Actions',
    dataIndex: 'actions',
    width: 200,
    align: 'center',
    render: (text) => <Button border={true}>Save Contact</Button>
  },
  {
    title: 'Contact Location',
    dataIndex: 'location',
    width: 200,
    align: 'center',
  },
  {
    title: 'Industry',
    dataIndex: 'industry',
    width: 200,
    align: 'center',
    render: (text) => (<div className='table-item'>Information Technology</div>)
  },
  {
    title: 'Employees',
    dataIndex: 'employees',
    width: 200,
    align: 'center',
  },
  {
    title: 'Keywords',
    dataIndex: 'keywords',
    width: 200,
    align: 'center',
  },
];

const data = [
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 1 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 2 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 3 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 4 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 5 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 6 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 7 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 8 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 9 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 10 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 11 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 12 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 13 },
  { name: 'Jack', title: 'Sales Executive - Apprentice', actions: 1, location: 'Hale, United Kingdom', keywords: 'some where', employees: 6, key: 14 },
  
];

const FilterContent = () => {
  const [active, setActive] = useState(1);
  const cmp = tabList.find((item) => item.id === active);
  return (
      <div className="filter-content">
        <div className="filter-content-head">
          <div className='filter-content-head'>
          <img src={list1} alt="" className='handle-icon'/>
          {
              tabList.map((item) => (
                <div 
                  className={`${active === item.id ? 'filter-content-head-active': ''} filter-content-head-item`}
                  key={item.id}
                  onClick={() => setActive(item.id)}
                >
                {item.name}
                </div>
              ))
            }
          </div>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            textAlign: 'right',
          }}>
            <img src={list1} alt="" className='handle-icon'/>
            <img src={list2} alt="" className='handle-icon'/>
            <img src={list3} alt="" className='handle-icon'/>
          </div>
        </div>
        {
          _jsx(cmp.component, {})
        }
      </div>
  );
};

export default FilterContent;