import FilterList from '../../../pages/search/company/components/FilterList';
import FilterContent from './components/FilterContent';
import './index.less';

const Company = () => {
  return (
    <div className='flex wrapper'>
        <FilterList />
        <FilterContent />
    </div>
  )
};

export default Company;