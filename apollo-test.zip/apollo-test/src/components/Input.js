import React, {
    useState,
    useRef,
    useMemo,
    useEffect,
    useLayoutEffect,
    memo
  } from 'react';
import './index.less';
import searchIcon from '@/assets/imgs/search.svg';
//   import Field from '../Field';
  
  const Input = memo(({
    value,
    onChange,
    valid,
    className,
    forwardedref,
    onBlur,
    onFocus,
    ...props
  }) => {
    const [words, setWords] = useState(value);
    const [isDirty, setDirty] = useState(false);
    const inputRef = useRef();
    const [isActive, setActive] = useState(false);
    const [isEnter, setEnter] = useState(false);
    const mountedSaved = useRef(true);
  
    useLayoutEffect(() => {
      mountedSaved.current = true;
      return () => {
        mountedSaved.current = false;
      };
    }, []);
  
    useEffect(() => {
      if (mountedSaved.current && document.activeElement !== inputRef.current) {
        setWords(value);
      }
    }, [value, setWords, isActive]);
  
    const invalid = useMemo(() => {
      if (valid == null) {
        return false;
      }
      if (isActive || !isDirty) {
        return false;
      }
      return !valid;
    }, [valid, isActive, isDirty]);
  
    return (
      <div
        isActive={isActive}
        onMouseEnter={() => setEnter(true)}
        onMouseLeave={() => setEnter(false)}
        className='test-input'
      >
        <img src={searchIcon} alt="" className='input-search-icon'/>
        <input
          {...props}
          ref={(ref) => {
            inputRef.current = ref;
            if (forwardedref) {
              if (typeof forwardedref === 'function') {
                forwardedref(ref);
              } else {
                forwardedref.current = ref;
              }
            }
          }}
          onChange={(ev) => {
            if (!isDirty) {
              setDirty(true);
            }
            setWords(ev.target.value);
          }}
          value={words}
          onFocus={(ev) => {
            setActive(true);
            if (onFocus) {
              onFocus(ev);
            }
          }}
          onBlur={(ev) => {
            if (value !== words) {
              onChange(words);
            }
            setActive(false);
            if (onBlur) {
              onBlur(ev);
            }
          }}
        />
      </div>
    );
  });

  export default React.forwardRef((props, ref) => (
    <Input
      {...props}
      forwardedref={ref}
    />
  ));
  