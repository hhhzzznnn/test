import { memo } from 'react';

const Button = memo(({
  type = 'default',
  pending,
  children,
  border,
  block,
  disabled,
  ...other
}) => {
  const themeMap = {
    default: {
      background: border ? '#fff' : '#1991eb',
      borderColor: border ? '#ccc' : '#1991eb',
      color: border ? '#aaa' : '#fff',
    //   active: {
    //     color: border ? color.active('#666') : '#fff',
    //     background: border ? chroma('#fff').darken(0.4).css() : color.active('#666'),
    //   },
    },
  };

  const theme = themeMap[type];
  return (
    <button
      type="button"
      className='test-button'
      {...other}
      style={{
        background: theme.background,
        color: pending ? 'rgba(0, 0, 0, 0)' : theme.color,
        border: `1px solid ${theme.borderColor}`,
        pointerEvents: pending ? 'none' : 'all',
        display: block ? 'flex' : 'inline-flex',
        userSelect: pending ? 'none' : 'auto',
        width: block ? '100%' : 'auto',
        height: '32px',
        transition: 'background 0.3s, color 0.3s, border-color 0.3s',
        cursor: disabled ? 'not-allowed' : 'pointer',
        width: block ? '100%' : 'auto',
        // &:active {
        //     color: ${theme.active.color};
        //     border-color: ${color.active(theme.borderColor)};
        //     background: ${theme.active.background};
        // }
      }}
    >
      {
          children
        }
    </button>
  );
});

export default Button;
