import { memo, useRef, useEffect } from 'react';
import ReactDOM from 'react-dom';
import useRectPosition from '@/hooks/useRectPosition';
import useElemRect from '@/hooks/useElemRect';
import ContentScroll, { ScrollBar } from '@/components/ContentScroll';
import Content from './Content';

const DISPLAY_COUNT = 8;

const PopList = memo(({
  className,
  list,
  children,
  elem,
  onHide,
  itemHeight=32
}) => {
  const container = useRef();
  const containerHeight = Math.min(list.length, DISPLAY_COUNT) * 2;
  const rect = useElemRect(elem);

  const [x, y] = useRectPosition(rect.width, containerHeight, rect);

  useEffect(() => {
    const handleClick = (ev) => {
      if (onHide
        && container.current
        && !container.current.contains(ev.target)
        && !elem.contains(ev.target)
      ) {
        onHide();
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => {
      document.removeEventListener('mousedown', handleClick);
    };
  }, [onHide, elem]);

  return ReactDOM.createPortal((
    <div
      className={className}
      onMouseDown={(ev) => ev.preventDefault()}
      ref={container}
      style={{
        position: 'absolute',
        background: '#fff',
        boxShadow: '0 0 4px rgba(0, 0, 0, 0.1)',
        zIndex: 1009,
        top: y,
        left: x,
        width: rect.width,
      }}
    >
      <ContentScroll
        scrollHeight={itemHeight * list.length}
        height={list.length > DISPLAY_COUNT ? itemHeight * DISPLAY_COUNT : itemHeight * list.length}
      >
        <Content
          itemHeight={itemHeight}
          list={list}
          displayCount={DISPLAY_COUNT}
        >
          {children}
        </Content>
        <ScrollBar />
      </ContentScroll>
    </div>
  ), document.body);
});

export default PopList;
