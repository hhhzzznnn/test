import { useMemo, memo } from 'react';
import { useScroll } from '@/components/ContentScroll';

const Content = memo(({
  itemHeight = 32,
  list,
  children,
  displayCount,
}) => {
  const { scrollTop } = useScroll();

  const {
    list: displayList,
    y: offsetY,
    index: offsetIndex,
  } = useMemo(() => {
    const len = list.length;
    if (len <= (displayCount + 2)) {
      return {
        list,
        y: scrollTop,
        index: 0,
      };
    }
    const index = Math.floor(scrollTop / itemHeight);
    const y = Math.min(Math.max(scrollTop - index * itemHeight, 0), itemHeight);
    return {
      index,
      y,
      list: list.slice(index, index + displayCount + 1),
    };
  }, [
    list,
    itemHeight,
    scrollTop,
    displayCount,
  ]);

  return (
    <div
      style={{
        transform: `translateY(-${offsetY}px)`,
      }}
    >
      {
        displayList
          .map((item, i) => (
            <div
              key={item.id}
              style={{
                height: itemHeight,
              }}
            >
              {children(item, i + offsetIndex)}
            </div>
          ))
      }
    </div>
  );
});

export default Content;
