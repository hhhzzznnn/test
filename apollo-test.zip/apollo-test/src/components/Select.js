import React, {
  useState,
  useMemo,
  useCallback,
  Fragment,
  useRef,
  memo,
} from 'react';
import PopList from '@/components/PopList';

const Select = memo(({
  list,
  placeholder,
  value,
  onChange,
  className,
}) => {
  const [isMouseEnter, setMouseEnter] = useState(false);
  const [isActive, setActive] = useState(false);
  const container = useRef();

  const displayText = useMemo(() => {
    if (value == null) {
      return placeholder || '';
    }
    return list.find((item) => item.id === value)?.name || placeholder;
  }, [value, list, placeholder]);


  const handleHide = useCallback(() => {
    setActive(false);
  }, [setActive]);

  return (
    <Fragment>
      <div
        ref={container}
        className={className}
      >
        <div
          className='select-wrapper'
          isActive={isActive}
          onMouseEnter={() => setMouseEnter(true)}
          onMouseLeave={() => setMouseEnter(false)}
        >
          <a
            className='select-title'
            title={value == null ? '' : displayText}
            onMouseDown={() => {
              setActive(!isActive);
            }}
          >
            <span style={{
                color: value == null ? '#b3b3b3' : null,
              }}
            >
              {displayText}
            </span>
          </a>
        </div>
      </div>
      {
        isActive && (
          <PopList
            list={list}
            elem={container.current}
            onHide={handleHide}
          >
            {
              (item) => (
                <a className='select-wrapper'
                  onMouseDown={(ev) => {
                    ev.preventDefault();
                    if (item.id !== value) {
                      onChange(item.id);
                    }
                    setActive(false);
                  }}
                  title={item.name}
                >
                  <span className='select-text'>
                    {item.name}
                  </span>
                </a>
              )
            }
          </PopList>
        )
      }
    </Fragment>
  );
});

export default Select;
