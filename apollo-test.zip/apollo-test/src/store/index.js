import { configureStore, getDefaultMiddleware } from '@reduxjs/toolkit';
import nav from './nav';

export default configureStore({
  reducer: {
    nav,
  },
  middleware: [
    ...getDefaultMiddleware({serializableCheck: false}), 
  ],
})