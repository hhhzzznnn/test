import { createSlice } from '@reduxjs/toolkit'

export const navSlice = createSlice({
  name: 'nav',
  initialState: {
    value: [],
    baseUrl: '',
  },
  reducers: {
    setList: (state, action) => { 
      state.value = action.payload 
    },
    setBaseUrl: (state, action) => { 
      state.baseUrl = action.payload 
    }
  }
})
export const { setList, setBaseUrl } = navSlice.actions;

export default navSlice.reducer;