export default [
    {
      name: 'Home',
      path: '/home',
      component: require('@/pages/search/company').default,
      children: [
        {
          name: 'Onboarding',
          path: '/onboarding',
          component: require('@/pages/search/company').default,
        },
        {
          name: 'Control center',
          path: '/control',
          component: require('@/pages/search/company').default,
        },
      ]
    },
    {
      name: 'Search',
      path: '/search',
      redirect: '/search/people',
      component: require('@/pages/search/company').default,
      children: [
        {
          name: 'People',
          path: '/people',
          component: require('@/pages/search/company').default,
        },
        {
          name: 'Companies',
          path: '/companies',
          component: require('@/pages/search/company').default,
        },
        {
          name: 'Lists',
          path: '/detail',
          component: require('@/pages/search/company').default,
        },
        {
          name: 'Saved Searches',
          path: '/searches',
          component: require('@/pages/search/company').default,
        }
      ]
    },
    {
      name: 'Engage',
      path: '/engage',
      component: require('@/pages/search/company').default,
      children: [
        {
          name: 'Email',
          path: '/email',
          component: require('@/pages/search/company').default,
        },
        {
          name: 'Calls',
          path: '/calls',
          component: require('@/pages/search/company').default,
        },
      ]
    },
    {
      name: 'Enrich',
      path: '/enrich',
      component: require('@/pages/search/company').default,
      children: [
        {
          name: 'Overview',
          path: '/overview',
          component: require('@/pages/search/company').default,
        },
        {
          name: 'CRM',
          path: '/crm',
          component: require('@/pages/search/company').default,
        },
      ]
    },
  ]
  